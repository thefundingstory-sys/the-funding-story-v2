import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'The Funding Story — Capital. People. Ideas. Impact.',
  description: 'India startup, funding, VC, technology and founder intelligence.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
