import { ArrowRight, Search, TrendingUp, Rocket, Users, Cpu, UserRound, BarChart3, Mail, Play, ChevronDown } from 'lucide-react';

const trending = [
  ['01','Zepto raises $350M in mega round, signals India’s quick-commerce is far from over','5 min read','/images/zepto.svg'],
  ['02','PhonePe reportedly in talks for $1.5B secondary round','4 min read','/images/phonepe.svg'],
  ['03','Ola Electric to raise ₹3,200 Cr in fresh funding','4 min read','/images/ola.svg'],
  ['04','India’s AI startups see 3x funding surge in 2025','5 min read','/images/ai.svg'],
  ['05','Sequoia backs climate-tech startup Varaha with $50M','4 min read','/images/varaha.svg'],
];
const stories = [
  ['FUNDING','Zomato’s Blinkit eyes $1B war chest for next phase of expansion','27 Sep 2025 · 4 min read','/images/zomato.svg'],
  ['FUNDING','Razorpay files for IPO, looks to raise ₹2,600 Cr','27 Sep 2025 · 5 min read','/images/razorpay.svg'],
  ['TECH','India’s AI startups see record investor interest in 2025','27 Sep 2025 · 6 min read','/images/ai.svg'],
  ['STARTUPS','CRED explores new revenue lines beyond credit cards','26 Sep 2025 · 4 min read','/images/cred.svg'],
];
const categories = [
  ['Funding', 'Latest funding rounds and deal news', TrendingUp],
  ['Startups', 'Emerging startups and ecosystem', Rocket],
  ['VC', 'Venture capital moves and insights', Users],
  ['Tech', 'Technology trends and innovation', Cpu],
  ['Founders', 'Stories, interviews and founder journeys', UserRound],
  ['Markets', 'Public markets and investment trends', BarChart3],
];

function Logo(){return <div className="logo"><strong>THE <span>FUNDING</span> STORY</strong><small>CAPITAL · PEOPLE · IDEAS · IMPACT</small></div>}
function Pill({children}:{children:React.ReactNode}){return <span className="pill">{children}</span>}
function CardImage({src}:{src:string}){return <div className="cardImage" style={{backgroundImage:`url(${src})`}} />}

export default function Home(){
  return <main>
    <header className="top">
      <div className="nav wrap"><Logo/><nav>{['Home','Funding','Startups','VC','Tech','Founders','Markets'].map((x,i)=><a className={i===0?'active':''} key={x}>{x}</a>)}<a>More <ChevronDown size={13}/></a></nav><div className="actions"><button className="search"><Search size={18}/><span>Search companies, founders...</span></button><button className="subscribe">Subscribe</button></div></div>
      <div className="ticker"><div className="wrap tickerInner"><span>NIFTY 50 <b>24,702.30</b> <em>+0.68% ↗</em></span><span>SENSEX <b>81,317.1</b> <em>+0.71% ↗</em></span><span>USD/INR <b>83.24</b> <i>-0.12% ↘</i></span><span>GOLD <b>78,320</b> <em>+0.45% ↗</em></span><span>SILVER <b>94,210</b> <em>+0.62% ↗</em></span><span className="time">27 Sep 2025, 01:32 PM</span></div></div>
    </header>

    <section className="wrap heroGrid">
      <article className="hero"><div className="heroImage"/><div className="heroOverlay"/><div className="heroCopy"><Pill>FUNDING ·</Pill><h1>Zepto raises <mark>$350M</mark> in mega round, signals India’s quick-commerce is far from over</h1><p>The round values Zepto at around $5B, with strong participation from global and domestic investors, as the company doubles down on supply chain, dark stores and category expansion.</p><div className="read"><button><ArrowRight size={22}/></button><div><strong>Read the full story →</strong><small>By TFS Desk · 27 Sep 2025 · 5 min read</small></div></div></div></article>
      <aside className="trending"><div className="sectionHead"><h2>Trending Now</h2><a>View all →</a></div>{trending.map(([n,t,time,img])=><div className="trend" key={n}><strong>{n}</strong><div className="mini" style={{backgroundImage:`url(${img})`}}/><div><h3>{t}</h3><small>{time}</small></div></div>)}</aside>
    </section>

    <section className="wrap categories">{categories.map(([name,desc,Icon])=><div className="category" key={name}><Icon/><div><strong>{name}</strong><small>{desc}</small></div></div>)}</section>

    <section className="wrap contentGrid">
      <div><div className="sectionHead"><h2>Latest Stories</h2><a>View all →</a></div><div className="storyGrid">{stories.map(([tag,title,date,img])=><article className="story" key={title}><CardImage src={img}/><Pill>{tag}</Pill><h3>{title}</h3><small>{date}</small></article>)}</div></div>
      <div className="rightCol"><div className="sectionHead"><h2>Funding Rounds</h2><a>View all →</a></div><div className="table"><div className="tr th"><span>Company</span><span>Amount</span><span>Stage</span><span>Investors</span></div>{[['Zepto','$350M','Series F','StepStone, Nexus...','/images/zepto.svg'],['Varaha','$50M','Series B','Sequoia, Accel','/images/varaha.svg'],['Porter','$200M','Series E','Tiger Global...','/images/porter.svg'],['Ather Energy','$150M','Series D','NIIF, GIC...','/images/ather.svg'],['Lenskart','$100M','Series F','Temasek, KKR','/images/lenskart.svg']].map(r=><div className="tr" key={r[0]}><span className="company"><img src={r[4]}/>{r[0]}</span><span>{r[1]}</span><span>{r[2]}</span><span>{r[3]}</span></div>)}</div>
        <div className="sectionHead interviewHead"><h2>Featured Interview</h2><a>View all →</a></div><article className="interview"><div className="person"/><div><Pill>FOUNDERS</Pill><h3>“India’s next wave of innovation will come from tier 2 and 3 cities”</h3><p>In conversation with a new generation of founders building for India.</p><button className="play"><Play size={14} fill="currentColor"/> 8 min read</button></div></article>
      </div>
    </section>

    <section className="wrap brief"><div className="briefIcon"><Mail/></div><div><h2>The Funding Brief</h2><p>Get the most important startup, funding and VC news delivered to your inbox every morning.</p></div><div className="email"><input placeholder="Enter your email address"/><button>Subscribe</button></div><div className="stats"><b>50K+<small>Subscribers</small></b><b>Daily<small>Funding Brief</small></b><b>No Spam<small>Only quality insights</small></b></div></section>

    <section className="wrap"><div className="sectionHead"><h2>Popular Companies</h2><a>View all →</a></div><div className="companies">{[['Zepto','E-commerce','$14.8B+','/images/zepto.svg'],['PhonePe','Fintech','$3B+','/images/phonepe.svg'],['Ola','Mobility','$4.2B+','/images/ola.svg'],['CRED','Fintech','$1B+','/images/cred.svg'],['Lenskart','Consumer','$1.2B+','/images/lenskart.svg'],['Groww','Fintech','$700M+','/images/groww.svg']].map(r=><div className="companyCard" key={r[0]}><img src={r[3]}/><div><strong>{r[0]}</strong><small>{r[1]}</small><em>{r[2]}</em></div></div>)}</div></section>

    <footer><div className="wrap footerGrid"><div><Logo/><div className="social"><span>in</span><span>𝕏</span><span>◎</span><span>▶</span></div></div><div><h4>Explore</h4><a>Funding</a><a>Startups</a><a>VC</a><a>Tech</a><a>Founders</a><a>Markets</a></div><div><h4>Company</h4><a>About Us</a><a>Contact</a><a>Advertise</a><a>Careers</a><a>Newsletter</a><a>Privacy Policy</a></div><div><h4>Resources</h4><a>Funding Database</a><a>Startup Directory</a><a>Investor Directory</a><a>Reports</a><a>Events</a><a>Submit a Story</a></div><div><h4>Stay Updated</h4><p>Weekly funding insights, straight to your inbox.</p><div className="footerInput"><input placeholder="Enter your email"/><button>→</button></div></div></div><div className="wrap copyright">© 2025 The Funding Story. All rights reserved.<span>♥ Built for India’s startup ecosystem</span></div></footer>
  </main>
}
