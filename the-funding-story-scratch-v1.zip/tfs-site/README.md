# The Funding Story — Scratch Rebuild

Premium dark financial/startup media homepage using Next.js + TypeScript + Tailwind-style custom CSS. This is the visual foundation only; the article CMS, Supabase database, API, authentication, SEO data layer, analytics and publishing workflows are intentionally not connected yet.

## Run locally

```bash
npm install
npm run dev
```
Open http://localhost:3000

## Deploy

Push this project to GitHub and import the repository into Vercel. Connect `www.thefundingstory.com` only after the new deployment is verified on its Vercel preview URL.

## Next build phases
1. Supabase schema and authentication
2. Admin CMS and article editor
3. TFS API routes
4. Dynamic article/category/company pages
5. SEO/schema/sitemap/RSS
6. Analytics and newsletter
7. AI/automation integrations
